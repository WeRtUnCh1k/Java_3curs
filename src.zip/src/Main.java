import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        OrderService service = new OrderService();

        Customer c1 = new Customer(1, "Олександр", "alex@gmail.com");
        Customer c2 = new Customer(2, "Марія", "maria@gmail.com");

        Product p1 = new Product(101, "Laptop", ProductCategory.ELECTRONICS, 35000.0);
        Product p2 = new Product(102, "Book Java", ProductCategory.BOOKS, 850.0);
        Product p3 = new Product(103, "T-Shirt", ProductCategory.CLOTHING, 400.0);
        Product p4 = new Product(104, "Coffee Maker", ProductCategory.HOME, 2500.0);

        Order o1 = new Order(1, c1, Arrays.asList(p1, p2), OrderStatus.NEW);
        Order o2 = new Order(2, c1, Arrays.asList(p3), OrderStatus.PROCESSING);
        Order o3 = new Order(3, c2, Arrays.asList(p2, p4), OrderStatus.DELIVERED);

        service.addOrder(o1);
        service.addOrder(o2);
        service.addOrder(o3);

        System.out.println("=== ДЕМОНСТРАЦІЯ РОБОТИ ORDER SERVICE ===\n");

        System.out.println("1. Пошук замовлення за ID (2): " + service.findOrderById(2));

        System.out.println("2. Замовлення клієнта Олександр (ID: 1):");
        service.findOrdersByCustomer(1).forEach(o -> System.out.println("   - " + o));

        System.out.println("3. Замовлення зі статусом NEW:");
        service.findOrdersByStatus(OrderStatus.NEW).forEach(o -> System.out.println("   - " + o));

        System.out.println("4. Замовлення, що містять продукт 'Book Java' (ID: 102):");
        service.findOrdersContainingProduct(102).forEach(o -> System.out.println("   - " + o));

        System.out.println("5. Сума замовлення ID 1: " + service.calculateOrderTotal(1) + " грн");

        System.out.println("6. Унікальні клієнти, які мають замовлення:");
        service.findCustomersWithOrders().forEach(c -> System.out.println("   - " + c.getName()));

        System.out.println("7. Замовлення відсортовані за загальною вартістю (зростання):");
        service.sortOrdersByTotalPrice().forEach(o -> 
            System.out.println("   - Замовлення #" + o.getId() + " | Сума: " + service.calculateOrderTotal(o.getId()) + " грн")
        );

        System.out.println("8. Статистика замовлень за статусами:");
        service.countOrdersByStatus().forEach((status, count) -> 
            System.out.println("   - " + status + ": " + count)
        );

        service.removeOrder(2);
        System.out.println("\n9. Після видалення замовлення ID 2, загальна кількість замовлень у статусі PROCESSING: " + 
                service.findOrdersByStatus(OrderStatus.PROCESSING).size());
    }
}